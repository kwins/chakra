This is the list of all known third-party plugins for RocksDB. If something is missing, please open a pull request to add it.

* [Dedupfs](https://github.com/ajkr/dedupfs): an example for plugin developers to reference
